# Peenapo-Page-Builder
Peenapo Pege Builder is a drag &amp; drop back-end, shortcode based page builder plugin for WordPress.

THIS PLUGIN AND ALL FILES INCLUDED ARE COPYRIGHT © Peenapo Themes 2015.
YOU MAY NOT RESELL, DISTRIBUTE, OR COPY THIS CODE IN ANY WAY. THE PLUGIN CAN ONLY BE USED WITH PEENAPO THEMES.

# Changelog

v1.3
- fixed: display table added table-layout:fixed;, bwpb-slider width fixed
- added: parameter - posts
- improved: performance
- fixed: conflict with bbpress plugin
- changed: owl carousel from beta version 2.0 to 1.3.3
- fixed: pie chart animation not working
- fixed: textfield param placeholder
- improved: element description removed, allow empty description for element mapping
- added: pe icon 7 stroke font
- removed: openiconic and entypo fonts
- owlCarousel library: version 2.0 beta replaced
- fixed: js error
- removed: main color parameter
- improved: elements styles

v1.2
- fixed: video for background muted
- added: element google map - open first pin at start
- added: element google map - infobox
- added: element google map - pin sequence animation
- fixed: element separator - margin bottom
- added: element - contact from 7, if plugin active
- added: developers documentation
- added: google map full page height option
- added: condition when checkbox is disabled
- improved: google map class selectors
- fixed: 80%, 100% table window height
- added: new config root for peenapo themes
- added: new template root for peenapo themes
- fixed: php conflict with updater.php

v1.1
- fixed: text editor missing breaklines and text format
- improved: back-end UI
- added: element colors
- added: element icons
- added: element filter
- improved: add new element UI
- fixed: google map styles missing
- removed: separator with text element
- fixed: some back-end UI issues
- php error with icons
- added: enable / disable teble alignment via global config
- added: global configuration loading both plugin and theme file

v1.0
- Initial Release