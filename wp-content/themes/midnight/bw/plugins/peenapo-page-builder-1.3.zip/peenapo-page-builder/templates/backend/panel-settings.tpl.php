<div id='bwpb-panel' class='bwpb-panel bwpb-draggable'>
    <form name='bwpb-panel-form' id='bwpb-panel-form'>
        <div class='panel-header'>
            <h4 class='panel-title'></h4>
            <span class='panel-h-button panel-close button-close'></span>
            <span class='panel-h-button panel-extra-class'></span>
            <span class='panel-extra-class-label'></span>
            <input type='text' class='bwpb-heading-class' name='class' value='' placeholder='Additional class name'>
         </div>
        <div class='panel-preloader'></div>
        <div class='panel-content'></div>
        <div class='panel-footer'>
            <div class='panel-scripts'></div>
            <span class='panel-button button-close'><?php _e( 'Close', PBTD ); ?></span>
            <span class='panel-button button-save'><?php _e( 'Save settings', PBTD ); ?></span>
        </div>
    </form>
</div>