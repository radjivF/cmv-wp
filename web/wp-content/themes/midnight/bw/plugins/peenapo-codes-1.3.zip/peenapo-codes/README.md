# Peenapo-Codes
WordPress meta options plugin everywhere, awesomeness and more.

# Changelog

v1.3
- fixed: updater
- fixed: radio button image missing conditional logic

v1.2
- fixed: acf - when creating a new field group - standard (wp metabox) is selected by default
- fixed: acf - radio image bug
- fixed: php conflict with updater.php

v1.1
- moved: updater
- moved: acf plugins

v1.0

- Initial Release